// NOME:  Emanuely Macedo Padovan
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

import ListaScreen from "../screens/ListaScreen";
import PerfilScreen from "../screens/PerfilScreen";
import StackNavigator from "./StackNavigator";

const Tab = createBottomTabNavigator();

export default function TabNavigator() {
  return (
      <Tab.Navigator screenOptions={{ headerShown: false }}>
        <Tab.Screen name="Musicas" component={StackNavigator}></Tab.Screen>
        <Tab.Screen name="Lista" component={ListaScreen}></Tab.Screen>
        <Tab.Screen name="Perfil" component={PerfilScreen}></Tab.Screen>
      </Tab.Navigator>
  );
}
